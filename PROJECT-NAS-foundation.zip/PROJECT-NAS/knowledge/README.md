# Knowledge

This is the canonical home for durable knowledge.

Suggested domains:
- identity
- principles
- skills
- prompts
- references
- playbooks

Do not import large historical documents blindly. First identify their canonical concepts and provenance.
