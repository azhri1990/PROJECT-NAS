# Skills

Skills represent repeatable capabilities rather than static biographies.

A mature skill can contain:
- knowledge
- procedures
- checklists
- references
- validation
- examples
