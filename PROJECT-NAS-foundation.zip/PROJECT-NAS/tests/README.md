# Tests

Foundation tests validate repository integrity rather than application behavior.

Current validation entry point:

```bash
python scripts/validate.py
```
