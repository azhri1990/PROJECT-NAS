# Operations

Operations turns PROJECT-NAS from a knowledge store into an execution system.

Planned domains:
- objectives
- projects
- tasks
- routines
- reviews
- retrospectives
