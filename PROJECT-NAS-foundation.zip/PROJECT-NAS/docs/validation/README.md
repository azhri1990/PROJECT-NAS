# Validation

Foundation validation is intentionally lightweight.

Run:

```bash
python scripts/validate.py
```

The validator checks required foundation files, JSON validity, internal Markdown references, and obvious secret patterns.
