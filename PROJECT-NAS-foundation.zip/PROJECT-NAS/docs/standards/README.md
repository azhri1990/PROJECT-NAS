# Authoritative Standards

This directory contains the rules that govern how PROJECT-NAS is built and maintained.

## Initial standards

- `repository.md` — structure and naming
- `development-environment.md` — reproducible setup
- `documentation.md` — documentation and canonical-source rules
- `validation.md` — quality gates
- `security.md` — secret and data handling

If a lower-level document conflicts with an approved standard, the standard wins.
