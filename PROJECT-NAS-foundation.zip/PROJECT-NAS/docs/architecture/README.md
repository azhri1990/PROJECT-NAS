# Architecture

PROJECT-NAS is organized around domains rather than a premature application framework.

## Domains

| Domain | Purpose |
|---|---|
| knowledge | Durable information and references |
| skills | Repeatable capabilities, procedures, and playbooks |
| operations | Objectives, projects, tasks, routines, reviews |
| security | Threats, data classification, backup, recovery |
| docs | Standards, architecture, governance, decisions |
| tests | Repository and integrity validation |
| scripts | Deterministic maintenance and validation |

## Boundary rule

External services and AI providers must be accessed through explicit integration boundaries. Credentials and provider-specific configuration must never become embedded in canonical knowledge artifacts.
