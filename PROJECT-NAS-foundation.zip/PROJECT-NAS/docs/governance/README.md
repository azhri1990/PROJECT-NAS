# Governance

PROJECT-NAS uses lightweight governance to prevent uncontrolled growth.

## Change classes

- **Routine:** documentation/content corrections.
- **Structural:** repository architecture or schemas.
- **Authoritative:** standards, policies, or core operating rules.
- **Security:** trust boundaries, secrets, data handling, or recovery.

Structural, authoritative, and security changes require a reviewable rationale.
