# Security

Security is a first-class PROJECT-NAS domain.

Planned components:
- threat model
- data classification
- secret handling
- backup strategy
- recovery procedure
- validation controls

See `docs/standards/security.md` for baseline rules.
